import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Volume2,
  Upload,
  Music,
  Heart,
  MoreHorizontal,
  Disc3,
  Trash2,
  Loader2,
  ExternalLink
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/integrations/supabase/client';

interface Track {
  id: string;
  name: string;
  url: string;
  duration?: number;
  isLiked?: boolean;
  artist?: string;
  album?: string;
  size: number;
  created_at: string;
}

const MusicPlayer = () => {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(75);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadingTracks, setUploadingTracks] = useState<Set<string>>(new Set());

  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Load tracks from Supabase
  useEffect(() => {
    fetchTracks();
  }, []);

  const fetchTracks = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('study_materials')
        .select('*')
        .eq('type', 'audio')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const musicTracks: Track[] = (data || []).map(item => ({
        id: item.id,
        name: item.name,
        url: item.url,
        duration: 0,
        isLiked: false,
        artist: item.uploaded_by || 'Unknown Artist',
        album: item.category || 'Unknown Album',
        size: item.size,
        created_at: item.created_at
      }));

      setTracks(musicTracks);
    } catch (error) {
      console.error('Error fetching tracks:', error);
      toast({
        title: "Error",
        description: "Failed to load music tracks",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    
    for (const file of files) {
      // Check if it's an audio file
      if (!file.type.startsWith('audio/')) {
        toast({
          title: "Invalid File",
          description: `${file.name} is not an audio file`,
          variant: "destructive",
        });
        continue;
      }

      const trackId = Math.random().toString(36).substr(2, 9);
      setUploadingTracks(prev => new Set(prev).add(trackId));

      try {
        // Upload file to Supabase Storage
        const filePath = `${Date.now()}-${file.name}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('music-files')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('music-files')
          .getPublicUrl(filePath);

        // Get audio duration
        const audio = new Audio();
        audio.src = URL.createObjectURL(file);
        
        audio.addEventListener('loadedmetadata', async () => {
          try {
            // Save metadata to database
            const { data: dbData, error: dbError } = await supabase
              .from('study_materials')
              .insert({
                name: file.name.replace(/\.[^/.]+$/, ""),
                type: 'audio',
                size: file.size,
                url: publicUrl,
                category: 'Music',
                tags: ['music', 'audio'],
                uploaded_by: 'Music Player',
              })
              .select()
              .single();

            if (dbError) throw dbError;

            // Add to local state
            const newTrack: Track = {
              id: dbData.id,
              name: dbData.name,
              url: dbData.url,
              duration: audio.duration,
              isLiked: false,
              artist: 'Music Player',
              album: 'Music',
              size: dbData.size,
              created_at: dbData.created_at
            };

            setTracks(prev => [newTrack, ...prev]);
            
            toast({
              title: "Music Uploaded! 🎵",
              description: `${file.name} has been uploaded and is now available to all users`,
            });
          } catch (error) {
            console.error('Error saving track metadata:', error);
            toast({
              title: "Upload Failed",
              description: `Failed to save ${file.name}`,
              variant: "destructive",
            });
          } finally {
            setUploadingTracks(prev => {
              const newSet = new Set(prev);
              newSet.delete(trackId);
              return newSet;
            });
            URL.revokeObjectURL(audio.src);
          }
        });

        audio.addEventListener('error', () => {
          setUploadingTracks(prev => {
            const newSet = new Set(prev);
            newSet.delete(trackId);
            return newSet;
          });
          toast({
            title: "Upload Failed",
            description: `Failed to process ${file.name}`,
            variant: "destructive",
          });
          URL.revokeObjectURL(audio.src);
        });

        audio.load();
      } catch (error) {
        console.error('Error uploading file:', error);
        setUploadingTracks(prev => {
          const newSet = new Set(prev);
          newSet.delete(trackId);
          return newSet;
        });
        toast({
          title: "Upload Failed",
          description: `Failed to upload ${file.name}`,
          variant: "destructive",
        });
      }
    }

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const deleteTrack = async (trackId: string) => {
    try {
      const { error } = await supabase
        .from('study_materials')
        .delete()
        .eq('id', trackId);

      if (error) throw error;

      setTracks(prev => prev.filter(track => track.id !== trackId));
      
      // If we deleted the currently playing track, stop playback
      const deletedIndex = tracks.findIndex(track => track.id === trackId);
      if (deletedIndex === currentTrackIndex) {
        setIsPlaying(false);
        setCurrentTime(0);
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.currentTime = 0;
        }
      } else if (deletedIndex < currentTrackIndex) {
        setCurrentTrackIndex(prev => prev - 1);
      }

      toast({
        title: "Track Deleted",
        description: "Music track removed successfully",
      });
    } catch (error) {
      console.error('Error deleting track:', error);
      toast({
        title: "Delete Failed",
        description: "Failed to delete track",
        variant: "destructive",
      });
    }
  };

  const playTrack = (index: number) => {
    if (!audioRef.current || !tracks[index]) return;
    
    setCurrentTrackIndex(index);
    audioRef.current.src = tracks[index].url;
    audioRef.current.play();
    setIsPlaying(true);
  };

  const togglePlayPause = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      if (!tracks[currentTrackIndex]) return;
      
      if (audioRef.current.src !== tracks[currentTrackIndex].url) {
        audioRef.current.src = tracks[currentTrackIndex].url;
      }
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const previousTrack = () => {
    const newIndex = isShuffle 
      ? Math.floor(Math.random() * tracks.length)
      : currentTrackIndex > 0 
        ? currentTrackIndex - 1 
        : tracks.length - 1;
    playTrack(newIndex);
  };

  const nextTrack = () => {
    const newIndex = isShuffle 
      ? Math.floor(Math.random() * tracks.length)
      : currentTrackIndex < tracks.length - 1 
        ? currentTrackIndex + 1 
        : 0;
    playTrack(newIndex);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleEnded = () => {
    if (isRepeat) {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play();
      }
    } else {
      nextTrack();
    }
  };

  const handleSeek = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
    if (audioRef.current) {
      audioRef.current.volume = value[0] / 100;
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const toggleLike = (trackId: string) => {
    setTracks(prev => prev.map(track => 
      track.id === trackId 
        ? { ...track, isLiked: !track.isLiked }
        : track
    ));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Update document title with current track
  useEffect(() => {
    if (tracks[currentTrackIndex]) {
      document.title = `${tracks[currentTrackIndex].name} - StudyVerse`;
    } else {
      document.title = 'StudyVerse';
    }
  }, [currentTrackIndex, tracks]);

  // Set up audio event listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);
    audio.volume = volume / 100;

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [currentTrackIndex, isRepeat, volume]);

  if (isLoading) {
    return (
      <Card className="widget">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
            <p>Loading music library...</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="widget">
      <div className="space-y-6">
        {/* Spotify Redirect Header */}
        <div className="mb-6 p-4 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                <Music className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-green-600 dark:text-green-400">Better Music Experience</h3>
                <p className="text-sm text-muted-foreground">Listen to millions of songs on Spotify</p>
              </div>
            </div>
            <Button 
              onClick={() => window.open('https://open.spotify.com/', '_blank')}
              className="bg-green-500 hover:bg-green-600 text-white"
              size="sm"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Spotify
            </Button>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
              <Music className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Shared Music Player</h3>
              <p className="text-sm text-muted-foreground">
                {tracks.length} track{tracks.length !== 1 ? 's' : ''} shared by the community
              </p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://open.spotify.com/', '_blank')}
              className="bg-green-500/10 border-green-500/30 text-green-600 hover:bg-green-500/20"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Spotify
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="glass-button"
              disabled={uploadingTracks.size > 0}
            >
              {uploadingTracks.size > 0 ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Upload className="w-4 h-4 mr-2" />
              )}
              {uploadingTracks.size > 0 ? 'Uploading...' : 'Upload Music'}
            </Button>
          </div>
        </div>

        {/* Upload Input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="audio/*"
          onChange={handleFileUpload}
          className="hidden"
        />

        {/* Current Track Display */}
        {tracks[currentTrackIndex] && (
          <div className="p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-primary rounded-lg flex items-center justify-center">
                <Disc3 className={`w-8 h-8 text-white ${isPlaying ? 'animate-spin' : ''}`} />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">{tracks[currentTrackIndex].name}</h4>
                <p className="text-sm text-muted-foreground">
                  {tracks[currentTrackIndex].artist} • {tracks[currentTrackIndex].album}
                </p>
                <Badge variant="secondary" className="mt-1">
                  {formatFileSize(tracks[currentTrackIndex].size)}
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleLike(tracks[currentTrackIndex].id)}
              >
                <Heart 
                  className={`w-5 h-5 ${tracks[currentTrackIndex].isLiked ? 'fill-red-500 text-red-500' : ''}`} 
                />
              </Button>
            </div>
          </div>
        )}

        {/* Player Controls */}
        <div className="space-y-4">
          {/* Progress Bar */}
          <div className="space-y-2">
            <Slider
              value={[currentTime]}
              max={duration || 100}
              step={1}
              onValueChange={handleSeek}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsShuffle(!isShuffle)}
              className={isShuffle ? 'text-primary' : ''}
            >
              <Shuffle className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={previousTrack}
              disabled={tracks.length === 0}
            >
              <SkipBack className="w-4 h-4" />
            </Button>
            
            <Button
              size="lg"
              onClick={togglePlayPause}
              disabled={tracks.length === 0}
              className="w-12 h-12 rounded-full"
            >
              {isPlaying ? 
                <Pause className="w-6 h-6" /> : 
                <Play className="w-6 h-6" />
              }
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={nextTrack}
              disabled={tracks.length === 0}
            >
              <SkipForward className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsRepeat(!isRepeat)}
              className={isRepeat ? 'text-primary' : ''}
            >
              <Repeat className="w-4 h-4" />
            </Button>
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-3">
            <Volume2 className="w-4 h-4" />
            <Slider
              value={[volume]}
              max={100}
              step={1}
              onValueChange={handleVolumeChange}
              className="flex-1"
            />
            <span className="text-xs text-muted-foreground w-8">{volume}%</span>
          </div>
        </div>

        {/* Track List */}
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {tracks.length > 0 ? (
            tracks.map((track, index) => (
              <div
                key={track.id}
                className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-muted/50 ${
                  index === currentTrackIndex ? 'bg-primary/10 border-primary' : ''
                }`}
                onClick={() => playTrack(index)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                      <Music className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium truncate">{track.name}</h5>
                      <p className="text-xs text-muted-foreground">
                        {track.artist} • {formatFileSize(track.size)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleLike(track.id);
                      }}
                    >
                      <Heart 
                        className={`w-4 h-4 ${track.isLiked ? 'fill-red-500 text-red-500' : ''}`} 
                      />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteTrack(track.id);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Music className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No music tracks found</p>
              <p className="text-sm">Upload your first track to get started!</p>
            </div>
          )}
        </div>

        {/* Audio Element */}
        <audio ref={audioRef} preload="metadata" />
      </div>
    </Card>
  );
};

export default MusicPlayer;