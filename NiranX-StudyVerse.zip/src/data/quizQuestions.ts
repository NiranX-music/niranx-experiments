export const chemistryQuestions = [
  {
    id: 'chem-1',
    question: 'What is the chemical formula for water?',
    options: ['H₂O', 'CO₂', 'O₂', 'H₂O₂'],
    correctAnswer: 0,
    explanation: 'Water consists of two hydrogen atoms bonded to one oxygen atom, hence H₂O.',
  },
  {
    id: 'chem-2',
    question: 'Which element has the atomic number 6?',
    options: ['Oxygen', 'Carbon', 'Nitrogen', 'Helium'],
    correctAnswer: 1,
    explanation: 'Carbon has 6 protons in its nucleus, giving it the atomic number 6.',
  },
  {
    id: 'chem-3',
    question: 'What type of bond involves sharing electrons?',
    options: ['Ionic bond', 'Covalent bond', 'Metallic bond', 'Hydrogen bond'],
    correctAnswer: 1,
    explanation: 'Covalent bonds form when atoms share electrons to achieve stability.',
  },
  {
    id: 'chem-4',
    question: 'What is the pH of a neutral solution?',
    options: ['0', '7', '14', '1'],
    correctAnswer: 1,
    explanation: 'A neutral solution has a pH of 7, which is neither acidic nor basic.',
  },
  {
    id: 'chem-5',
    question: 'Which gas is most abundant in Earth\'s atmosphere?',
    options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Argon'],
    correctAnswer: 2,
    explanation: 'Nitrogen makes up about 78% of Earth\'s atmosphere.',
  },
];

export const physicsQuestions = [
  {
    id: 'phys-1',
    question: 'What is the SI unit of force?',
    options: ['Joule', 'Newton', 'Watt', 'Pascal'],
    correctAnswer: 1,
    explanation: 'The Newton (N) is the SI unit of force, named after Isaac Newton.',
  },
  {
    id: 'phys-2',
    question: 'What is the speed of light in vacuum?',
    options: ['3 × 10⁸ m/s', '3 × 10⁶ m/s', '3 × 10⁴ m/s', '3 × 10¹⁰ m/s'],
    correctAnswer: 0,
    explanation: 'The speed of light in vacuum is approximately 299,792,458 m/s or 3 × 10⁸ m/s.',
  },
  {
    id: 'phys-3',
    question: 'What does Newton\'s First Law state?',
    options: [
      'Force equals mass times acceleration',
      'Every action has an equal and opposite reaction',
      'An object at rest stays at rest unless acted upon by a force',
      'Energy cannot be created or destroyed',
    ],
    correctAnswer: 2,
    explanation: 'Newton\'s First Law is the law of inertia, stating objects maintain their state of motion unless acted upon by an external force.',
  },
  {
    id: 'phys-4',
    question: 'What is the formula for kinetic energy?',
    options: ['KE = mv', 'KE = ½mv²', 'KE = mgh', 'KE = Fd'],
    correctAnswer: 1,
    explanation: 'Kinetic energy equals one-half the mass times velocity squared: KE = ½mv².',
  },
  {
    id: 'phys-5',
    question: 'What type of wave requires a medium to travel?',
    options: ['Electromagnetic wave', 'Light wave', 'Mechanical wave', 'Radio wave'],
    correctAnswer: 2,
    explanation: 'Mechanical waves, like sound waves, require a medium (solid, liquid, or gas) to propagate.',
  },
];

export const biologyQuestions = [
  {
    id: 'bio-1',
    question: 'What is the powerhouse of the cell?',
    options: ['Nucleus', 'Mitochondria', 'Chloroplast', 'Ribosome'],
    correctAnswer: 1,
    explanation: 'Mitochondria generate energy (ATP) for the cell through cellular respiration.',
  },
  {
    id: 'bio-2',
    question: 'Which base pairs with Adenine in DNA?',
    options: ['Guanine', 'Cytosine', 'Thymine', 'Uracil'],
    correctAnswer: 2,
    explanation: 'In DNA, Adenine (A) pairs with Thymine (T), while Guanine (G) pairs with Cytosine (C).',
  },
  {
    id: 'bio-3',
    question: 'What is the basic unit of life?',
    options: ['Tissue', 'Organ', 'Cell', 'Organism'],
    correctAnswer: 2,
    explanation: 'The cell is the smallest unit of life that can function independently.',
  },
  {
    id: 'bio-4',
    question: 'What process do plants use to make food?',
    options: ['Cellular respiration', 'Photosynthesis', 'Fermentation', 'Digestion'],
    correctAnswer: 1,
    explanation: 'Plants use photosynthesis to convert light energy into chemical energy (glucose).',
  },
  {
    id: 'bio-5',
    question: 'How many chromosomes do humans have?',
    options: ['23', '46', '48', '92'],
    correctAnswer: 1,
    explanation: 'Humans have 46 chromosomes in total: 23 pairs, with one chromosome in each pair from each parent.',
  },
];
