import { useState, useRef, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { ArrowLeft, Code, Eye, Trash2, Copy, FileCode, Palette, Zap, Save, Globe, ExternalLink, MessageSquare, Send, Share2, Sparkles } from "lucide-react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";

export default function GeneratedWebsite() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("preview");
  const [activeCode, setActiveCode] = useState<"html" | "css" | "js">("html");
  const [isEditing, setIsEditing] = useState(false);
  const [editedCode, setEditedCode] = useState({ html: "", css: "", js: "" });
  const [slug, setSlug] = useState("");
  const [showAIChat, setShowAIChat] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{ role: string; content: string }>>([]);
  const [chatInput, setChatInput] = useState("");
  const [isAIProcessing, setIsAIProcessing] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages]);

  const { data: website, isLoading } = useQuery({
    queryKey: ["generated-website", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("generated_websites")
        .select("*")
        .eq("id", id)
        .single();

      if (error) throw error;
      
      // Initialize edit state and slug
      setEditedCode({
        html: data.html_code || "",
        css: data.css_code || "",
        js: data.js_code || ""
      });
      setSlug(data.slug || "");
      
      return data;
    },
  });

  const saveCodeMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("generated_websites")
        .update({
          html_code: editedCode.html,
          css_code: editedCode.css,
          js_code: editedCode.js,
          updated_at: new Date().toISOString()
        })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["generated-website", id] });
      toast.success("Website code saved successfully");
      setIsEditing(false);
    },
    onError: () => {
      toast.error("Failed to save website code");
    }
  });

  const publishMutation = useMutation({
    mutationFn: async () => {
      if (!slug || slug.trim() === "") {
        throw new Error("Please enter a URL slug");
      }

      // Validate slug format
      const slugRegex = /^[a-z0-9-]+$/;
      if (!slugRegex.test(slug)) {
        throw new Error("Slug can only contain lowercase letters, numbers, and hyphens");
      }

      const { error } = await supabase
        .from("generated_websites")
        .update({
          slug: slug.toLowerCase().trim(),
          is_published: true,
          published_at: new Date().toISOString()
        })
        .eq("id", id);

      if (error) {
        if (error.message.includes("duplicate") || error.message.includes("unique")) {
          throw new Error("This URL is already taken. Please choose another.");
        }
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["generated-website", id] });
      toast.success("Website published successfully!");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to publish website");
    }
  });

  const unpublishMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("generated_websites")
        .update({
          is_published: false
        })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["generated-website", id] });
      toast.success("Website unpublished");
    },
    onError: () => {
      toast.error("Failed to unpublish website");
    }
  });

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this website?")) return;

    const { error } = await supabase
      .from("generated_websites")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("Failed to delete website");
      return;
    }

    toast.success("Website deleted successfully");
    navigate("/niranx/ai-website-generator");
  };

  const copyToClipboard = (code: string, type: string) => {
    navigator.clipboard.writeText(code);
    toast.success(`${type} code copied to clipboard`);
  };

  const copyAllCode = () => {
    const allCode = `${website?.html_code || ""}\n\n/* CSS */\n${website?.css_code || ""}\n\n/* JavaScript */\n${website?.js_code || ""}`;
    navigator.clipboard.writeText(allCode);
    toast.success("All code copied to clipboard");
  };

  const handleSaveCode = () => {
    saveCodeMutation.mutate();
  };

  const handlePublish = () => {
    publishMutation.mutate();
  };

  const handleUnpublish = () => {
    unpublishMutation.mutate();
  };

  const getCurrentCode = () => {
    if (isEditing) {
      return activeCode === "html" ? editedCode.html :
             activeCode === "css" ? editedCode.css : editedCode.js;
    }
    return activeCode === "html" ? website?.html_code :
           activeCode === "css" ? website?.css_code : website?.js_code;
  };

  const handleCodeChange = (value: string) => {
    setEditedCode(prev => ({
      ...prev,
      [activeCode]: value
    }));
  };

  const handleAIUpgrade = async () => {
    if (!chatInput.trim() || isAIProcessing) return;

    const userMessage = { role: "user", content: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput("");
    setIsAIProcessing(true);

    try {
      const { data, error } = await supabase.functions.invoke('website-ai-chat', {
        body: {
          messages: [...chatMessages, userMessage],
          currentCode: isEditing ? editedCode : {
            html: website?.html_code,
            css: website?.css_code,
            js: website?.js_code
          }
        }
      });

      if (error) throw error;

      const assistantMessage = { role: "assistant", content: data.message };
      setChatMessages(prev => [...prev, assistantMessage]);

      // Update the edited code with AI suggestions
      if (data.code) {
        setEditedCode(data.code);
        setIsEditing(true);
        toast.success("Code updated! Review and save when ready.");
      }
    } catch (error: any) {
      console.error("AI upgrade error:", error);
      const errorMessage = { 
        role: "assistant", 
        content: `Sorry, I encountered an error: ${error.message || 'Please try again.'}` 
      };
      setChatMessages(prev => [...prev, errorMessage]);
      toast.error("Failed to process AI request");
    } finally {
      setIsAIProcessing(false);
    }
  };

  const handleShare = () => {
    const shareUrl = website?.is_published && website?.slug 
      ? `${window.location.origin}/w/${website.slug}`
      : window.location.href;

    if (navigator.share) {
      navigator.share({
        title: website?.title || "My Website",
        text: website?.description || "Check out my website!",
        url: shareUrl
      }).catch(() => {
        navigator.clipboard.writeText(shareUrl);
        toast.success("Link copied to clipboard!");
      });
    } else {
      navigator.clipboard.writeText(shareUrl);
      toast.success("Link copied to clipboard!");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading your website...</p>
        </div>
      </div>
    );
  }

  if (!website) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4 bg-background">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">Website not found</h2>
          <p className="text-muted-foreground">The website you're looking for doesn't exist.</p>
          <Button onClick={() => navigate("/niranx/ai-website-generator")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Generator
          </Button>
        </div>
      </div>
    );
  }

  const fullHTML = isEditing ? editedCode.html : website.html_code;
  const codeStats = {
    html: (isEditing ? editedCode.html : website.html_code)?.length || 0,
    css: (isEditing ? editedCode.css : website.css_code)?.length || 0,
    js: (isEditing ? editedCode.js : website.js_code)?.length || 0,
  };

  const currentCode = getCurrentCode();
  const publicUrl = website?.is_published && website?.slug 
    ? `${window.location.origin}/w/${website.slug}` 
    : null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate("/niranx/ai-website-generator")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">{website.title}</h1>
                <p className="text-sm text-muted-foreground line-clamp-1">{website.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
              {publicUrl && (
                <Button variant="outline" size="sm" onClick={() => window.open(publicUrl, '_blank')}>
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Live
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={copyAllCode}>
                <Copy className="mr-2 h-4 w-4" />
                Copy All
              </Button>
              <Button variant="destructive" size="sm" onClick={handleDelete}>
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-full max-w-md grid-cols-3 h-12">
              <TabsTrigger value="preview" className="gap-2">
                <Eye className="h-4 w-4" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="code" className="gap-2">
                <Code className="h-4 w-4" />
                Code Editor
              </TabsTrigger>
              <TabsTrigger value="publish" className="gap-2">
                <Globe className="h-4 w-4" />
                Publish
              </TabsTrigger>
            </TabsList>

            {activeTab === "code" && (
              <div className="flex items-center gap-2">
                {isEditing && (
                  <Button size="sm" onClick={handleSaveCode} disabled={saveCodeMutation.isPending}>
                    <Save className="h-4 w-4 mr-2" />
                    {saveCodeMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                )}
                <Button
                  variant={isEditing ? "outline" : "default"}
                  size="sm"
                  onClick={() => {
                    if (isEditing) {
                      setEditedCode({
                        html: website?.html_code || "",
                        css: website?.css_code || "",
                        js: website?.js_code || ""
                      });
                    }
                    setIsEditing(!isEditing);
                  }}
                >
                  <Code className="h-4 w-4 mr-2" />
                  {isEditing ? "Cancel" : "Edit Code"}
                </Button>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <FileCode className="h-4 w-4" />
                  <span>{codeStats.html + codeStats.css + codeStats.js} characters</span>
                </div>
              </div>
            )}
          </div>

          {/* Preview Tab */}
          <TabsContent value="preview" className="space-y-4 mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Preview Section */}
              <div className="lg:col-span-2">
                <Card className="overflow-hidden border-2">
                  <div className="bg-muted/50 border-b px-4 py-2 flex items-center gap-2">
                    <div className="flex gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <span className="text-sm text-muted-foreground ml-4">Live Preview</span>
                  </div>
                  <div className="bg-white">
                    <iframe
                      srcDoc={fullHTML}
                      className="w-full h-[calc(100vh-280px)] border-0"
                      title="Website Preview"
                      sandbox="allow-scripts"
                    />
                  </div>
                </Card>
              </div>

              {/* AI Chat Section */}
              <div className="lg:col-span-1">
                <Card className="overflow-hidden h-full flex flex-col">
                  <div className="bg-gradient-to-r from-primary/10 to-primary/5 border-b px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-primary" />
                      <h3 className="font-semibold">AI Assistant</h3>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Ask me to upgrade your website!
                    </p>
                  </div>
                  
                  <ScrollArea className="flex-1 p-4">
                    {chatMessages.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm font-medium mb-2">How can I help?</p>
                        <div className="mt-4 space-y-2 text-xs text-left">
                          <p className="font-medium">Try asking:</p>
                          <ul className="space-y-1.5">
                            <li className="bg-muted/50 p-2 rounded">💬 "Add a contact form"</li>
                            <li className="bg-muted/50 p-2 rounded">🎨 "Make it more colorful"</li>
                            <li className="bg-muted/50 p-2 rounded">📊 "Add a pricing section"</li>
                            <li className="bg-muted/50 p-2 rounded">✨ "Add animations"</li>
                          </ul>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {chatMessages.map((msg, idx) => (
                          <div
                            key={idx}
                            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                          >
                            <div
                              className={`max-w-[85%] rounded-lg px-3 py-2 ${
                                msg.role === "user"
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted"
                              }`}
                            >
                              <p className="text-xs whitespace-pre-wrap">{msg.content}</p>
                            </div>
                          </div>
                        ))}
                        {isAIProcessing && (
                          <div className="flex justify-start">
                            <div className="bg-muted rounded-lg px-3 py-2">
                              <div className="flex items-center gap-2">
                                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary"></div>
                                <span className="text-xs">Thinking...</span>
                              </div>
                            </div>
                          </div>
                        )}
                        <div ref={chatEndRef} />
                      </div>
                    )}
                  </ScrollArea>

                  <div className="border-t p-3">
                    <div className="flex gap-2">
                      <Input
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault();
                            handleAIUpgrade();
                          }
                        }}
                        placeholder="Ask AI to upgrade..."
                        disabled={isAIProcessing}
                        className="text-sm"
                      />
                      <Button
                        size="icon"
                        onClick={handleAIUpgrade}
                        disabled={!chatInput.trim() || isAIProcessing}
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Code Tab */}
          <TabsContent value="code" className="space-y-4 mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
              {/* Code Files Sidebar */}
              <div className="lg:col-span-1">
                <Card className="p-4">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <FileCode className="h-4 w-4" />
                    Files
                  </h3>
                  <div className="space-y-1">
                    <button
                      onClick={() => setActiveCode("html")}
                      className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors flex items-center gap-2 ${
                        activeCode === "html"
                          ? "bg-primary text-primary-foreground"
                          : "hover:bg-muted"
                      }`}
                    >
                      <FileCode className="h-4 w-4" />
                      index.html
                      <span className="ml-auto text-xs opacity-70">
                        {Math.round(codeStats.html / 1024)}KB
                      </span>
                    </button>
                    {website.css_code && (
                      <button
                        onClick={() => setActiveCode("css")}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors flex items-center gap-2 ${
                          activeCode === "css"
                            ? "bg-primary text-primary-foreground"
                            : "hover:bg-muted"
                        }`}
                      >
                        <Palette className="h-4 w-4" />
                        styles.css
                        <span className="ml-auto text-xs opacity-70">
                          {Math.round(codeStats.css / 1024)}KB
                        </span>
                      </button>
                    )}
                    {website.js_code && (
                      <button
                        onClick={() => setActiveCode("js")}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors flex items-center gap-2 ${
                          activeCode === "js"
                            ? "bg-primary text-primary-foreground"
                            : "hover:bg-muted"
                        }`}
                      >
                        <Zap className="h-4 w-4" />
                        script.js
                        <span className="ml-auto text-xs opacity-70">
                          {Math.round(codeStats.js / 1024)}KB
                        </span>
                      </button>
                    )}
                  </div>
                </Card>
              </div>

              {/* Code Editor */}
              <div className="lg:col-span-3 space-y-4">
                {/* AI Upgrade Button */}
                <Card className="p-3 bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">AI-Powered Upgrades</span>
                    </div>
                    <Button
                      size="sm"
                      variant={showAIChat ? "secondary" : "default"}
                      onClick={() => setShowAIChat(!showAIChat)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      {showAIChat ? "Hide Chat" : "Upgrade with AI"}
                    </Button>
                  </div>
                </Card>
                <Card className="overflow-hidden">
                  <div className="bg-muted/50 border-b px-4 py-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Code className="h-4 w-4" />
                      <span className="text-sm font-medium">
                        {activeCode === "html" && "index.html"}
                        {activeCode === "css" && "styles.css"}
                        {activeCode === "js" && "script.js"}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        const code = activeCode === "html" ? website.html_code : 
                                    activeCode === "css" ? website.css_code : website.js_code;
                        copyToClipboard(code || "", activeCode.toUpperCase());
                      }}
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                  <div className="max-h-[calc(100vh-280px)] overflow-auto">
                    {isEditing ? (
                      <Textarea
                        value={currentCode || ""}
                        onChange={(e) => handleCodeChange(e.target.value)}
                        className="min-h-[calc(100vh-280px)] font-mono text-sm"
                        placeholder={`Enter your ${activeCode.toUpperCase()} code here...`}
                      />
                    ) : (
                      <SyntaxHighlighter
                        language={activeCode === "html" ? "html" : activeCode === "css" ? "css" : "javascript"}
                        style={vscDarkPlus}
                        customStyle={{ 
                          margin: 0, 
                          borderRadius: 0,
                          fontSize: "14px",
                          lineHeight: "1.6"
                        }}
                        showLineNumbers
                        wrapLines
                      >
                        {currentCode || (activeCode === "css" ? "/* No additional CSS */" : "// No additional JavaScript")}
                      </SyntaxHighlighter>
                    )}
                  </div>
                </Card>

                {/* AI Chat Panel */}
                {showAIChat && (
                  <Card className="overflow-hidden">
                    <div className="bg-gradient-to-r from-primary/10 to-primary/5 border-b px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-primary" />
                        <h3 className="font-semibold">AI Website Assistant</h3>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Ask me to add features, change styles, or improve your website!
                      </p>
                    </div>
                    
                    <ScrollArea className="h-[300px] p-4">
                      {chatMessages.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                          <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                          <p className="text-sm">Start a conversation to upgrade your website</p>
                          <div className="mt-4 space-y-2 text-xs">
                            <p className="text-left">Try asking:</p>
                            <ul className="text-left list-disc list-inside space-y-1">
                              <li>"Add a contact form"</li>
                              <li>"Make the hero section more colorful"</li>
                              <li>"Add a pricing table"</li>
                              <li>"Improve the navigation menu"</li>
                            </ul>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {chatMessages.map((msg, idx) => (
                            <div
                              key={idx}
                              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                            >
                              <div
                                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                                  msg.role === "user"
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-muted"
                                }`}
                              >
                                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                              </div>
                            </div>
                          ))}
                          {isAIProcessing && (
                            <div className="flex justify-start">
                              <div className="bg-muted rounded-lg px-4 py-2">
                                <div className="flex items-center gap-2">
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                                  <span className="text-sm">Generating improvements...</span>
                                </div>
                              </div>
                            </div>
                          )}
                          <div ref={chatEndRef} />
                        </div>
                      )}
                    </ScrollArea>

                    <div className="border-t p-3">
                      <div className="flex gap-2">
                        <Input
                          value={chatInput}
                          onChange={(e) => setChatInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                              e.preventDefault();
                              handleAIUpgrade();
                            }
                          }}
                          placeholder="Describe what you want to add or change..."
                          disabled={isAIProcessing}
                        />
                        <Button
                          size="icon"
                          onClick={handleAIUpgrade}
                          disabled={!chatInput.trim() || isAIProcessing}
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Publish Tab */}
          <TabsContent value="publish" className="space-y-4 mt-0">
            <Card className="p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Publish Your Website</h3>
                  <p className="text-sm text-muted-foreground">
                    Make your website accessible via a custom URL that anyone can visit.
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="slug">Custom URL Slug</Label>
                    <div className="flex gap-2 mt-2">
                      <div className="flex items-center gap-2 px-3 py-2 bg-muted rounded-md text-sm">
                        {window.location.origin}/w/
                      </div>
                      <Input
                        id="slug"
                        value={slug}
                        onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                        placeholder="my-awesome-website"
                        disabled={website?.is_published}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Only lowercase letters, numbers, and hyphens allowed
                    </p>
                  </div>

                  {publicUrl && (
                    <div className="p-4 bg-muted rounded-lg">
                      <Label className="text-sm font-medium">Your Published URL</Label>
                      <div className="flex items-center gap-2 mt-2">
                        <code className="flex-1 px-3 py-2 bg-background rounded text-sm">
                          {publicUrl}
                        </code>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            navigator.clipboard.writeText(publicUrl);
                            toast.success("URL copied to clipboard");
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(publicUrl, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2">
                    {website?.is_published ? (
                      <Button
                        variant="destructive"
                        onClick={handleUnpublish}
                        disabled={unpublishMutation.isPending}
                      >
                        <Globe className="h-4 w-4 mr-2" />
                        {unpublishMutation.isPending ? "Unpublishing..." : "Unpublish Website"}
                      </Button>
                    ) : (
                      <Button
                        onClick={handlePublish}
                        disabled={!slug || publishMutation.isPending}
                      >
                        <Globe className="h-4 w-4 mr-2" />
                        {publishMutation.isPending ? "Publishing..." : "Publish Website"}
                      </Button>
                    )}
                  </div>

                  {website?.is_published && (
                    <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <p className="text-sm text-green-600 dark:text-green-400">
                        ✓ Your website is live and accessible to anyone with the URL!
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
