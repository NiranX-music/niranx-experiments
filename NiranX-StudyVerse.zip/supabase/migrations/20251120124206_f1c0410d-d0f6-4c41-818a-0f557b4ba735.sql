-- Enable realtime for leaderboard_entries table
ALTER PUBLICATION supabase_realtime ADD TABLE leaderboard_entries;