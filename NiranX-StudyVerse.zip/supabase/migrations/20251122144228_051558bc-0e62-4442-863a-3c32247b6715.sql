-- Enable realtime for guild messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.guild_messages;